# Magisk Module Template

This `README.md` will be shown in Magisk Manager. Place any information / changelog / notes you like.

**Please update `README.md` if you want to submit your module to the online repo!**

This modules enables some features on factory camera, like: manual mode, torch light, native 4k record, object following and so.